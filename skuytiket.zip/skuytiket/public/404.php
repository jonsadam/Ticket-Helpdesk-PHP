<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>404 - Halaman Tidak Ditemukan</title>
  <link rel="icon" href="../img/logo-ail.png">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center min-h-screen">
  <div class="text-center bg-white rounded-2xl shadow-2xl p-10 max-w-lg">
    <h1 class="text-7xl font-extrabold text-blue-600 mb-4">404</h1>
    <h2 class="text-2xl font-semibold mb-2">Halaman Tidak Ditemukan</h2>
    <p class="text-gray-600 mb-6">Ups! Halaman yang kamu cari tidak tersedia atau sudah dipindahkan.</p>
    <a href="./" class="inline-block px-6 py-3 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition">
      Kembali ke Dashboard
    </a>
  </div>
</body>
</html>
