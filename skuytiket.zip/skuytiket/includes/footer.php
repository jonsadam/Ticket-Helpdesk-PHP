<footer class="bg-blue-200 text-blue-800 text-center py-4 mt-auto">
    © <?php echo date("Y") ?> Lensajon Corp.
  </footer>